import { A, e } from "./mermaid-parser.core.BBstJ2Oi.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
