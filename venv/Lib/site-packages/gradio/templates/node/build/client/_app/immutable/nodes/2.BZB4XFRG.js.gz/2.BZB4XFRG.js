import { W, _ } from "../chunks/2.BnWZeegF.js";
export {
  W as component,
  _ as universal
};
