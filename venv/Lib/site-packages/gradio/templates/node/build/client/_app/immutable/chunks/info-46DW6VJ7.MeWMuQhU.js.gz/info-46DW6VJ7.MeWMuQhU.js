import { I, c } from "./mermaid-parser.core.BBstJ2Oi.js";
export {
  I as InfoModule,
  c as createInfoServices
};
