import { P, a } from "./mermaid-parser.core.BBstJ2Oi.js";
export {
  P as PacketModule,
  a as createPacketServices
};
