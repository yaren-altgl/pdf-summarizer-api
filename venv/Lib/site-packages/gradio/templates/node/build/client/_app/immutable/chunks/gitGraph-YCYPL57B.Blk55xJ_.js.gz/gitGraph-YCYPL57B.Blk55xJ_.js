import { G, f } from "./mermaid-parser.core.BBstJ2Oi.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
